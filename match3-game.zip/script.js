const rows = 8;
const cols = 8;
const colors = ['#e74c3c', '#3498db', '#2ecc71', '#f1c40f', '#9b59b6'];
let board = [];
let score = 0;
let level = 1;
let firstTile = null;

const container = document.getElementById('game-container');
const scoreEl = document.getElementById('score');

function initBoard() {
    board = [];
    container.innerHTML = '';
    for (let r = 0; r < rows; r++) {
        board[r] = [];
        for (let c = 0; c < cols; c++) {
            const color = colors[Math.floor(Math.random() * colors.length)];
            board[r][c] = color;
            const div = document.createElement('div');
            div.classList.add('tile');
            div.style.backgroundColor = color;
            div.dataset.row = r;
            div.dataset.col = c;
            div.addEventListener('click', tileClick);
            container.appendChild(div);
        }
    }
}

function tileClick(e) {
    const r = parseInt(this.dataset.row);
    const c = parseInt(this.dataset.col);
    if (!firstTile) {
        firstTile = {r, c};
        this.style.transform = 'scale(1.2)';
    } else {
        swap(firstTile.r, firstTile.c, r, c);
        firstTile = null;
        document.querySelectorAll('.tile').forEach(t => t.style.transform = '');
        checkMatches();
    }
}

function swap(r1, c1, r2, c2) {
    const temp = board[r1][c1];
    board[r1][c1] = board[r2][c2];
    board[r2][c2] = temp;
    renderBoard();
}

function renderBoard() {
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
            const div = container.children[r * cols + c];
            div.style.backgroundColor = board[r][c];
        }
    }
}

function checkMatches() {
    let matched = [];
    // горизонтальные
    for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols - 2; c++) {
            if (board[r][c] === board[r][c+1] && board[r][c] === board[r][c+2]) {
                matched.push([r,c], [r,c+1], [r,c+2]);
            }
        }
    }
    // вертикальные
    for (let c = 0; c < cols; c++) {
        for (let r = 0; r < rows - 2; r++) {
            if (board[r][c] === board[r+1][c] && board[r][c] === board[r+2][c]) {
                matched.push([r,c], [r+1,c], [r+2,c]);
            }
        }
    }
    if (matched.length > 0) {
        removeMatches(matched);
    }
}

function removeMatches(matched) {
    matched.forEach(([r,c]) => {
        board[r][c] = null;
        score += 10;
    });
    renderBoard();
    setTimeout(dropTiles, 300);
}

function dropTiles() {
    for (let c = 0; c < cols; c++) {
        let empty = 0;
        for (let r = rows -1; r >= 0; r--) {
            if (board[r][c] === null) {
                empty++;
            } else if (empty > 0) {
                board[r+empty][c] = board[r][c];
                board[r][c] = null;
            }
        }
        for (let i = 0; i < empty; i++) {
            board[i][c] = colors[Math.floor(Math.random() * colors.length)];
        }
    }
    renderBoard();
    updateScore();
    checkMatches();
}

function updateScore() {
    scoreEl.textContent = `Score: ${score} | Level: ${level}`;
}

initBoard();
